package com.example.aplicacion_citas_local;

import android.app.Activity;

public class CitasApp1Activity extends Activity {
}
