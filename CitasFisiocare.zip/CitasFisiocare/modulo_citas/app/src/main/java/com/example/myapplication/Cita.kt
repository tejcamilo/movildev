package com.example.myapplication

class Cita(var fecha: String?, var tipo: String?, var doctor: String?, var modalidad: String?)
