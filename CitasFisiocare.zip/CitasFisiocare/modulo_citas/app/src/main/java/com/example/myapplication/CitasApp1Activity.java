package com.example.myapplication;

import android.app.Activity;

public class CitasApp1Activity extends Activity {
}
