package com.example.citasfisiocare.model

data class Cita(
    val fecha: String,
    val hora: String,
    val especialidad: String,
    val modalidad: String
)
