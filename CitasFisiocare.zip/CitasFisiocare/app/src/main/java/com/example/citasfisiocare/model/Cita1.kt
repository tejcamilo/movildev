package com.example.citasfisiocare.model

data class Cita1(
    val idUsuario: String = "",
    val fecha: String = "",
    val hora: String = "",
    val especialidad: String = "",
    val modalidad: String = ""

)
